#!/usr/bin/env python3
"""cpcu_dsp.py — live DSP + ML inference pipeline for the CPCU.

Reads EMG from IPC ring, filters, extracts features, runs ML inference,
integrates servo targets via velocity mode, publishes motor commands.

Config sources (priority order):
  1. config/gestures.json    — gesture definitions, EMG channel map, confidence curve
  2. models/velocity_map.json — operator-calibrated rates (overrides gestures.json rates)
  3. config/runtime.json     — hardware tuning (smoother, grip, bias)
  4. models/*.pkl            — trained ML model + scaler
"""
import argparse
import json
import glob
import os
import re
import signal
import sys
import time
from collections import deque

import numpy as np
from scipy.signal import butter, filtfilt, iirnotch, decimate

from cpcu_ipc_bridge import IPCBridge

# ── paths ──
REPO_ROOT       = os.environ.get("CPCU_ROOT",
                    os.path.dirname(os.path.abspath(__file__)) + "/..")
GESTURES_PATH   = os.path.join(REPO_ROOT, "config", "gestures.json")
RUNTIME_PATH    = os.path.join(REPO_ROOT, "config", "runtime.json")
MODEL_DIR       = os.environ.get("CPCU_MODEL_DIR",
                    os.path.join(REPO_ROOT, "models"))
INSTALLED_MODEL = "/opt/cpcu/models"
INSTALLED_CFG   = "/opt/cpcu/config.json"
THRESHOLDS_PATH = os.path.join(MODEL_DIR, "noise_thresholds.json")

# ── sampling ──
INPUT_FS_HZ     = 2000
TARGET_FS_HZ    = 200
DECIMATE_FACTOR = INPUT_FS_HZ // TARGET_FS_HZ  # 10
WINDOW_MS       = 200
STRIDE_MS       = 100
WINDOW_HI       = INPUT_FS_HZ  * WINDOW_MS // 1000   # 400
STRIDE_HI       = INPUT_FS_HZ  * STRIDE_MS // 1000   # 200
WINDOW_LO       = TARGET_FS_HZ * WINDOW_MS // 1000   # 40
BUFFER_SIZE     = WINDOW_HI * 4                       # 1600

# ── defaults (overridden by config files) ──
ADC_MIDRAIL     = 2048
NUM_SERVOS      = 6
SERVO_NEUTRAL   = 1500
DRAIN_PERIOD_S  = 0.020
DRAIN_BATCH     = 200
PROB_THRESH     = 0.65

SERVO_MIN_US    = [498, 1074, 1074, 1001, 1001, 976]
SERVO_MAX_US    = [2500, 1953, 1953, 2002, 2002, 1733]


# ══════════════════════════════════════════════════════════════════════
#  CONFIG LOADERS
# ══════════════════════════════════════════════════════════════════════

def load_gestures(path=GESTURES_PATH):
    """Load gestures.json. Returns (gestures_dict, emg_channels, confidence_cfg)
    or defaults on failure."""
    defaults = (
        {"rest": {"mode": "freeze", "channels": {}}},
        [0, 1, 2],
        {"curve": "quadratic", "floor_pct": 40, "ceil_pct": 85}
    )
    try:
        with open(path) as f:
            gs = json.load(f)
        gestures = gs.get("gestures", defaults[0])
        emg_ch   = gs.get("emg_channels", {}).get("active", defaults[1])
        conf_cfg = gs.get("confidence", defaults[2])
        servo_ch = gs.get("servo_channels", {})
        # resolve servo channel names to indices
        name_to_idx = {n: d["pca_ch"] for n, d in servo_ch.items()}
        # convert gesture channel names to index-based rates
        for gname, gdef in gestures.items():
            raw_ch = gdef.get("channels", {})
            rates = [0] * NUM_SERVOS
            snap_flags = [False] * NUM_SERVOS
            smoother_v = [0] * NUM_SERVOS
            smoother_a = [0] * NUM_SERVOS
            for sname, chdef in raw_ch.items():
                idx = name_to_idx.get(sname)
                if idx is None:
                    print(f"[DSP] gestures.json: unknown servo '{sname}'", flush=True)
                    continue
                rates[idx] = chdef.get("rate_us_s", 0)
                snap_flags[idx] = chdef.get("snap", False)
                so = gdef.get("smoother_override", {}).get(sname, {})
                smoother_v[idx] = so.get("velocity_us_s", 0)
                smoother_a[idx] = so.get("accel_us_s2", 0)
            gdef["_rates"] = rates
            gdef["_snap"] = snap_flags
            gdef["_smooth_v"] = smoother_v
            gdef["_smooth_a"] = smoother_a
        print(f"[DSP] gestures.json: {list(gestures.keys())}", flush=True)
        return gestures, emg_ch, conf_cfg
    except Exception as e:
        print(f"[DSP] gestures.json load failed: {e}, using defaults", flush=True)
        return defaults


def load_velocity_map(operator="default"):
    """Load operator-calibrated velocity overrides from velocity_map.json.
    Returns {gesture: {servo_idx: rate_us_s}} or empty dict."""
    if operator == "default":
        path = os.path.join(MODEL_DIR, "velocity_map.json")
    else:
        path = os.path.join(MODEL_DIR, f"velocity_map_{operator}.json")
    try:
        with open(path) as f:
            vm = json.load(f)
        if not vm.get("calibrated_at"):
            return {}  # template, not calibrated
        result = {}
        for gname, servos in vm.get("gesture_levels", {}).items():
            result[gname] = {}
            for sname, sdef in servos.items():
                result[gname][sname] = sdef.get("rate_us_s", 0)
        print(f"[DSP] velocity_map ({operator}): {list(result.keys())}", flush=True)
        return result
    except (OSError, ValueError):
        return {}


def load_runtime(path=None):
    """Load hardware tuning from runtime.json.
    Returns (hysteresis_votes, grip_firm_us)."""
    votes = 3
    grip_firm = 1100
    candidates = [path] if path else [INSTALLED_CFG, RUNTIME_PATH]
    for p in candidates:
        if not p:
            continue
        try:
            with open(p) as f:
                text = f.read()
            # strip // comment lines (legacy format tolerance)
            text = re.sub(r'//[^\n]*', '', text)
            text = re.sub(r',(\s*[}\]])', r'\1', text)
            raw = json.loads(text)
            if "hysteresis_votes" in raw:
                votes = int(raw["hysteresis_votes"])
            if "grip_firm_us" in raw:
                v = int(raw["grip_firm_us"])
                if 800 <= v <= 2200:
                    grip_firm = v
            print(f"[DSP] runtime: votes={votes} grip_firm={grip_firm}", flush=True)
            return votes, grip_firm
        except Exception as e:
            print(f"[DSP] runtime {p}: {e}", flush=True)
    return votes, grip_firm


def discover_model():
    """Find and load ML model. Returns (model, scaler) or (None, None).
    Search order: MODEL_DIR/*.pkl, INSTALLED_MODEL/*.pkl, legacy .joblib."""
    try:
        import joblib
    except ImportError:
        print("[DSP] joblib missing — feature-only mode", flush=True)
        return None, None

    search_dirs = [MODEL_DIR, INSTALLED_MODEL]
    for d in search_dirs:
        # combined .pkl (dict with model+scaler)
        for pkl in sorted(glob.glob(os.path.join(d, "*.pkl"))):
            try:
                cp = joblib.load(pkl)
                if isinstance(cp, dict) and "model" in cp and "scaler" in cp:
                    print(f"[DSP] model: {pkl}", flush=True)
                    return cp["model"], cp["scaler"]
            except Exception as e:
                print(f"[DSP] {pkl}: {e}", flush=True)
        # legacy separate .joblib files
        m_path = os.path.join(d, "hmi_svm_model_200hz.joblib")
        s_path = os.path.join(d, "hmi_scaler_200hz.joblib")
        if os.path.exists(m_path) and os.path.exists(s_path):
            try:
                return joblib.load(m_path), joblib.load(s_path)
            except Exception as e:
                print(f"[DSP] joblib load: {e}", flush=True)

    print(f"[DSP] no model found — feature-only mode", flush=True)
    return None, None


# ══════════════════════════════════════════════════════════════════════
#  DSP FILTERS — direct ports of the team's pipeline
# ══════════════════════════════════════════════════════════════════════

def butter_bandpass(data, low, high, fs, order=4):
    nyq = 0.5 * fs
    if high >= nyq:
        high = nyq * 0.95
    b, a = butter(order, [low/nyq, high/nyq], btype='band')
    return filtfilt(b, a, data)

def notch_filter(data, f0, fs, q=30.0):
    nyq = 0.5 * fs
    w0 = f0 / nyq
    if w0 >= 1:
        return data
    b, a = iirnotch(w0, q)
    return filtfilt(b, a, data)

def envelope(data, fs, cutoff=3.0):
    nyq = 0.5 * fs
    b, a = butter(4, cutoff/nyq, btype='low')
    return filtfilt(b, a, np.abs(data))

def extract_features(clean, env):
    """4 features per channel: RMS, VAR, WL, ENV-mean."""
    eps = 1e-8
    rms = float(np.sqrt(np.mean(clean ** 2) + eps))
    var = float(np.var(clean))
    wl  = float(np.sum(np.abs(np.diff(clean))) / len(clean))
    em  = float(np.mean(env))
    return [rms, var, wl, em]

def process_window(window_hi):
    """Full pipeline on a 400-sample @ 2 kHz window.
    DC remove → bandpass 20-450 Hz → notch 50/100/200 Hz → decimate → envelope."""
    centered = window_hi - np.mean(window_hi)
    bp   = butter_bandpass(centered, 20.0, 450.0, INPUT_FS_HZ)
    n50  = notch_filter(bp, 50.0, INPUT_FS_HZ)
    n100 = notch_filter(n50, 100.0, INPUT_FS_HZ)
    n200 = notch_filter(n100, 200.0, INPUT_FS_HZ)
    cleaned = decimate(n200, DECIMATE_FACTOR, zero_phase=True)
    env = envelope(cleaned, TARGET_FS_HZ, cutoff=3.0)
    return cleaned, env, extract_features(cleaned, env)


# ══════════════════════════════════════════════════════════════════════
#  CONFIDENCE CURVE
# ══════════════════════════════════════════════════════════════════════

def confidence_scale(conf_frac, floor, ceil, curve="quadratic"):
    """Map SVM confidence [0,1] to velocity scale [0,1].
    quadratic: slow start, fast finish. linear: legacy."""
    if conf_frac <= floor:
        return 0.0
    if conf_frac >= ceil:
        return 1.0
    t = (conf_frac - floor) / (ceil - floor)
    if curve == "quadratic":
        return t * t
    return t  # linear fallback


# ══════════════════════════════════════════════════════════════════════
#  UART DEBUG (optional)
# ══════════════════════════════════════════════════════════════════════

UART_PORT = os.environ.get("CPCU_UART_DEBUG", "")
_uart = None

def _uart_init():
    global _uart
    if not UART_PORT:
        return
    try:
        import serial
        _uart = serial.Serial(UART_PORT, 115200, timeout=0)
        print(f"[DSP] UART debug → {UART_PORT}", flush=True)
    except Exception as e:
        print(f"[DSP] UART: {e}", flush=True)

def _uart_send(gesture, conf, feats):
    if _uart is None:
        return
    try:
        ts = int(time.time() * 1000)
        csv = ",".join(f"{v:.6f}" for v in feats)
        _uart.write(f"{ts},{gesture},{conf:.3f},{csv}\n".encode())
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════
#  MAIN INFERENCE LOOP
# ══════════════════════════════════════════════════════════════════════

def run_inference(verbose=False, operator="default"):
    # ── load config ──
    gestures, active_channels, conf_cfg = load_gestures()
    num_ch = len(active_channels)
    hysteresis_votes, grip_firm = load_runtime()
    vel_overrides = load_velocity_map(operator)

    # apply velocity_map overrides to gesture rates
    servo_channels = {}
    try:
        with open(GESTURES_PATH) as f:
            gs_raw = json.load(f)
        servo_channels = gs_raw.get("servo_channels", {})
    except Exception:
        pass
    name_to_idx = {n: d["pca_ch"] for n, d in servo_channels.items()}

    for gname, overrides in vel_overrides.items():
        if gname not in gestures:
            continue
        for sname, rate in overrides.items():
            idx = name_to_idx.get(sname)
            if idx is not None and "_rates" in gestures[gname]:
                gestures[gname]["_rates"][idx] = rate

    # per-gesture grip_firm override
    for gname, gdef in gestures.items():
        if "grip_firm_us" in gdef:
            gdef["_grip_firm"] = gdef["grip_firm_us"]
        else:
            gdef["_grip_firm"] = grip_firm

    # confidence curve
    conf_floor = conf_cfg.get("floor_pct", 40) / 100.0
    conf_ceil  = conf_cfg.get("ceil_pct", 85) / 100.0
    conf_curve = conf_cfg.get("curve", "quadratic")
    if conf_floor >= conf_ceil:
        conf_floor, conf_ceil = 0.40, 0.85

    # ── load model ──
    model, scaler = discover_model()
    inference_on = model is not None
    if inference_on:
        classes = [str(c) for c in model.classes_]
        n_feat = scaler.n_features_in_
        expected = num_ch * 4
        if n_feat != expected:
            print(f"[DSP] WARNING: model expects {n_feat} features, "
                  f"pipeline produces {expected}", flush=True)
        # cross-check gesture names
        for cls in classes:
            if cls not in gestures:
                print(f"[DSP] model class '{cls}' not in gestures.json "
                      f"— will fall back to neutral", flush=True)
        print(f"[DSP] model classes: {classes}", flush=True)

    # ── IPC ──
    ipc = IPCBridge()
    ipc.set_dsp_ready()
    print(f"[DSP] ready. channels={active_channels} "
          f"curve={conf_curve} votes={hysteresis_votes}", flush=True)

    _uart_init()

    # ── state ──
    buffers = [deque([0]*BUFFER_SIZE, maxlen=BUFFER_SIZE) for _ in range(num_ch)]
    samples_since_window = 0
    total_samples = 0
    current_state = "rest"
    consec_count = 0
    last_active = 0
    current_target = [SERVO_NEUTRAL] * NUM_SERVOS
    last_int_t = time.monotonic()
    last_safe = False
    edit_mode = False
    inferences = 0
    last_report = time.monotonic()

    running = [True]
    def stop(sig, _):
        running[0] = False
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    while running[0]:
        t0 = time.monotonic()

        # ── 1. drain ring ──
        t_drain_start = time.monotonic()
        batch = ipc.pop_sensor_batch(DRAIN_BATCH)
        n = batch.get('count', 0)
        if n > 0:
            ipc.inc_dsp_batches(n)
            samples = batch['samples']
            for ei in range(n):
                for si in range(2):
                    for bi, ch in enumerate(active_channels):
                        buffers[bi].append(
                            int(samples[ei, si, ch]) - ADC_MIDRAIL)
            added = n * 2
            samples_since_window += added
            total_samples += added
        t_drain = time.monotonic() - t_drain_start

        # ── 2. check window readiness ──
        ready = (samples_since_window >= STRIDE_HI
                 and total_samples >= WINDOW_HI)

        if ready:
            t_dsp_start = time.monotonic()
            samples_since_window = 0

            # ── 3. feature extraction ──
            features_flat = []
            rms_8ch = [0.0] * 8
            for bi, ch in enumerate(active_channels):
                w = np.array(list(buffers[bi])[-WINDOW_HI:], dtype=np.float64)
                _cl, _ev, feats = process_window(w)
                features_flat.extend(feats)
                rms_8ch[ch] = feats[0]
                try:
                    ipc.write_dsp_filtered_window(ch, _ev,
                                                  sample_rate_hz=TARGET_FS_HZ)
                except Exception:
                    pass

            t_dsp = time.monotonic() - t_dsp_start

            # ── 4. inference + debounce ──
            conf_pct = 0
            class_conf = []
            if inference_on:
                X = np.asarray(features_flat, dtype=np.float64).reshape(1, -1)
                Xs = scaler.transform(X)
                probs = model.predict_proba(Xs)[0]
                ai = int(np.argmax(probs))
                label = str(model.classes_[ai])
                conf = float(probs[ai])

                if conf > PROB_THRESH and label != current_state:
                    consec_count += 1
                    if consec_count >= hysteresis_votes:
                        current_state = label
                        consec_count = 0
                else:
                    consec_count = 0

                last_active = ai
                class_conf = list(probs)
                conf_pct = int(round(conf * 100.0))

                _uart_send(current_state, conf, features_flat)

            # ── 5. publish dsp export ──
            inf_us = int((time.monotonic() - t_dsp_start) * 1e6)
            ipc.update_dsp_max_latency(inf_us)
            ipc.write_dsp_export(
                channel_rms=rms_8ch,
                gesture_name=current_state,
                class_confidence=class_conf,
                active_class=last_active,
                inference_time_us=inf_us,
            )

            # ── 6. edit-mode handshake ──
            edit_req = ipc.read_edit_request()
            if edit_req:
                if not edit_mode:
                    current_state = "rest"
                    consec_count = 0
                    current_target = [SERVO_NEUTRAL] * NUM_SERVOS
                    ipc.write_edit_dsp_ack(1)
                    edit_mode = True
                last_int_t = time.monotonic()
            else:
                if edit_mode:
                    ipc.write_edit_dsp_ack(0)
                    edit_mode = False

                # fault recovery: snap to neutral if SAFE was entered
                sys_state = ipc.read_system_state()
                in_safe = (sys_state == 2)
                if in_safe and not last_safe:
                    current_target = [SERVO_NEUTRAL] * NUM_SERVOS
                last_safe = in_safe

                # ── 7. velocity integration ──
                t_vel_start = time.monotonic()
                now = time.monotonic()
                dt = now - last_int_t
                last_int_t = now
                if dt > 0.5:
                    dt = 0.0  # stall guard

                conf_frac = conf_pct / 100.0
                scale = confidence_scale(conf_frac, conf_floor,
                                         conf_ceil, conf_curve)

                gdef = gestures.get(current_state)
                if gdef is None:
                    # unknown class → neutral
                    current_target = [SERVO_NEUTRAL] * NUM_SERVOS
                elif gdef.get("mode") == "freeze":
                    if current_state == "rest":
                        current_target = [SERVO_NEUTRAL] * NUM_SERVOS
                else:
                    # velocity mode
                    rates = gdef.get("_rates", [0]*NUM_SERVOS)
                    gf = gdef.get("_grip_firm", grip_firm)
                    for s in range(NUM_SERVOS):
                        delta = rates[s] * dt * scale
                        nv = current_target[s] + delta
                        nv = max(SERVO_MIN_US[s], min(SERVO_MAX_US[s], nv))
                        if s == 5 and nv < gf:
                            nv = gf  # gripper soft-firm clamp
                        current_target[s] = nv

                servo_us = [int(round(v)) for v in current_target]
                ipc.write_motor_cmd(servo_us, last_active, conf_pct)
                t_vel = time.monotonic() - t_vel_start

            ipc.inc_dsp_inferences()
            inferences += 1

            if verbose:
                print(f"[DSP] {current_state} {conf_pct}% "
                      f"drain={t_drain*1e3:.1f}ms dsp={t_dsp*1e3:.1f}ms",
                      flush=True)

        # ── 8. periodic report ──
        if t0 - last_report >= 5.0:
            print(f"[DSP] inf={inferences} state={current_state} "
                  f"ring={ipc.sensor_count()}", flush=True)
            last_report = t0

        # ── 9. sleep remainder ──
        elapsed = time.monotonic() - t0
        if elapsed < DRAIN_PERIOD_S:
            time.sleep(DRAIN_PERIOD_S - elapsed)

    print("[DSP] shutdown", flush=True)
    ipc.close()
    return 0


# ══════════════════════════════════════════════════════════════════════
#  CALIBRATION MODE
# ══════════════════════════════════════════════════════════════════════

def run_calibrate(seconds):
    """Collect rest-state samples, compute 3*std per channel, save thresholds."""
    _, active_channels, _ = load_gestures()
    num_ch = len(active_channels)
    labels = [f"s{i+1}" for i in range(num_ch)]

    ipc = IPCBridge()
    print(f"[CAL] recording {seconds}s of rest...", flush=True)

    bufs = [deque(maxlen=int(INPUT_FS_HZ * (seconds + 1))) for _ in range(num_ch)]
    t_end = time.monotonic() + seconds
    while time.monotonic() < t_end:
        batch = ipc.pop_sensor_batch(DRAIN_BATCH)
        n = batch.get('count', 0)
        if n > 0:
            samples = batch['samples']
            for ei in range(n):
                for si in range(2):
                    for bi, ch in enumerate(active_channels):
                        bufs[bi].append(int(samples[ei, si, ch]) - ADC_MIDRAIL)
        time.sleep(DRAIN_PERIOD_S)

    thresholds = {}
    for bi, label in enumerate(labels):
        sig = np.array(bufs[bi], dtype=np.float64)
        if len(sig) < WINDOW_HI:
            thresholds[label] = 50.0
            continue
        sig_lo = decimate(sig, DECIMATE_FACTOR, zero_phase=True)
        centered = sig_lo - np.mean(sig_lo)
        bp = butter_bandpass(centered, 20.0, 450.0, TARGET_FS_HZ)
        cleaned = notch_filter(bp, 50.0, TARGET_FS_HZ)
        thr = float(np.std(cleaned) * 3.0)
        thresholds[label] = thr
        print(f"[CAL] {label} (ch{active_channels[bi]}): "
              f"std={np.std(cleaned):.2f} thr={thr:.2f}", flush=True)

    os.makedirs(MODEL_DIR, exist_ok=True)
    with open(THRESHOLDS_PATH, 'w') as f:
        json.dump(thresholds, f, indent=4)
    print(f"[CAL] saved: {THRESHOLDS_PATH}", flush=True)
    ipc.close()
    return 0


# ══════════════════════════════════════════════════════════════════════
#  ENTRY
# ══════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(description="CPCU DSP + ML pipeline")
    ap.add_argument('--calibrate', type=float, metavar='SEC',
                    help="Record N seconds of rest, save thresholds, exit")
    ap.add_argument('--verbose', action='store_true')
    ap.add_argument('--operator', default='default',
                    help="Load velocity_map_<name>.json profile")
    args = ap.parse_args()

    if args.calibrate is not None:
        return run_calibrate(args.calibrate)
    return run_inference(verbose=args.verbose, operator=args.operator)


if __name__ == "__main__":
    sys.exit(main())
